from django.apps import AppConfig


class GmConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gm'
